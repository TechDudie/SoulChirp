// a
function a() {
  send("a")
}

// b
function b() {
  send("b")
}

// c
function c() {
  send("c")
}

// d
function d() {
  send("d")
}

// send
function send(answer) {
  document.getElementById("code").value = answer;
  document.getElementById('form').submit();
}
