<?php
$question = "Hello World?";
$a = "Because";
$b = "For no reason";
$c = "Go away";
$d = "Bruh";
$answer = "a";
?>