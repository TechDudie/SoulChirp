<?php
include("settings.php");
$input = htmlentities($_POST["code"]);
$message = "Better luck next time!";
if ($input === $answer) {
  $message = "CORRECT!";
}
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>Game</title>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Ubuntu Mono'>
<link rel="stylesheet" href="css/game.css">
</head>
<body>
<div id="ask">
<h1 id="question"><?php echo $question; ?></h1>
<h1>Correct? Or wrong? Who knows?</h1>
<?php echo $message; ?>
</div>
<script src="js/game.js"></script>
<form id="form" action="join.php" method="POST">
<input type="text" id="code" name="code" value="0">
</form>
</div>
</body>
</html>
