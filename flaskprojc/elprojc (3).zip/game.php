<?php
$code = "000000";
if (isset($_COOKIE['code'])) {
  $code = $_COOKIE['code'];
}
if ($code != "314159") { // PIE IN YOUR FACE LITERALLY IF YOU READ THE JOIN CODE
  header('Location: 404.html');
  die();
}
if (!isset($_COOKIE['code'])) {
  setcookie("code", $code, time() + 60*60*24, "/");
}

include("settings.php");
?>
<html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>Game</title>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Ubuntu Mono'>
<link rel="stylesheet" href="css/game.css">
</head>
<body>
<div id="answer">
<div id="ask">
<h1 id="question"><?php echo $question; ?></h1>
</div>
<div id="container">
<button id="a" class="button" onclick="a()"><?php echo $a; ?></button>
<button id="b" class="button" onclick="b()"><?php echo $b; ?></button>
<button id="c" class="button" onclick="c()"><?php echo $c; ?></button>
<button id="d" class="button" onclick="d()"><?php echo $d; ?></button>
</div>
</div>
</div>
<script src="js/game.js"></script>
<form id="form" action="answer.php" method="POST">
<input type="text" id="code" name="code" value="0">
</form>
</body>
</html>
